"""Hacs models."""
